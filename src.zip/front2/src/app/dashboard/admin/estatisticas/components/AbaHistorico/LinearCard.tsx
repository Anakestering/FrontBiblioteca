'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  createChart,
  IChartApi,
  ISeriesApi,
  LineSeries,
  LineData,
  Time,
  ColorType,
  CrosshairMode,
  LineStyle,
  MouseEventParams,
} from 'lightweight-charts';
import { FiltrosRelatorio } from '../../page';
import { FiltroPeriodoInline, PeriodoFiltro } from '../FiltroPeriodoInline';
import { toISOLocal } from '@/lib/utils';
import { relatorios } from '@/lib/api';

interface Props {
  filtros: FiltrosRelatorio;
  globalVersao: number;
}

// O backend agora retorna mm (média móvel) e tendencia junto com cada ponto
interface PontoHistorico {
  data: string;
  total: number;
  mm?: number;
}

interface TendenciaDTO {
  pct: number;
  subindo: boolean;
}

type Agrupamento = 'dia' | 'semana' | 'mes';

const JANELA_MM: Record<Agrupamento, number> = { dia: 7, semana: 4, mes: 3 };

function toTime(data: string): Time {
  return data as Time;
}

function formatarLabel(data: string, agrupamento: Agrupamento): string {
  const [ano, mes, dia] = data.split('-');
  if (agrupamento === 'mes') {
    const MESES = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
    return `${MESES[parseInt(mes) - 1]} ${ano}`;
  }
  return `${dia}/${mes}`;
}

function formatarTooltip(data: string, agrupamento: Agrupamento): string {
  const [ano, mes, dia] = data.split('-');
  const MESES = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
  if (agrupamento === 'mes') return `${MESES[parseInt(mes) - 1]} de ${ano}`;
  if (agrupamento === 'semana') return `Semana de ${dia}/${mes}/${ano}`;
  return `${dia}/${mes}/${ano}`;
}

interface TooltipState {
  visible: boolean;
  x: number;
  y: number;
  data: string;
  total: number;
  mm?: number;
  agrupamento: Agrupamento;
}

function Tooltip({ state }: { state: TooltipState }) {
  if (!state.visible) return null;
  return (
    <div
      className="pointer-events-none absolute z-50"
      style={{ left: state.x + 12, top: state.y - 8, transform: 'translateY(-50%)' }}
    >
      <div style={{
        background: 'rgba(15,15,25,0.95)',
        border: '1px solid rgba(124,58,237,0.4)',
        borderRadius: 8,
        padding: '8px 12px',
        boxShadow: '0 4px 24px rgba(0,0,0,0.5)',
        backdropFilter: 'blur(8px)',
        minWidth: 140,
      }}>
        <p style={{ fontSize: 11, color: '#9ca3af', marginBottom: 6 }}>
          {formatarTooltip(state.data, state.agrupamento)}
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#7c3aed', flexShrink: 0 }} />
            <span style={{ fontSize: 12, color: '#e5e7eb' }}>
              <strong style={{ color: '#fff' }}>{state.total}</strong>
              <span style={{ color: '#9ca3af', marginLeft: 4 }}>reservas</span>
            </span>
          </div>
          {state.mm !== undefined && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ width: 8, height: 2, borderTop: '2px dashed #a78bfa', flexShrink: 0 }} />
              <span style={{ fontSize: 12, color: '#e5e7eb' }}>
                <strong style={{ color: '#a78bfa' }}>{state.mm.toFixed(1)}</strong>
                <span style={{ color: '#9ca3af', marginLeft: 4 }}>
                  média {JANELA_MM[state.agrupamento]}p
                </span>
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function LinearCard({ filtros, globalVersao }: Props) {
  const [dados, setDados]             = useState<PontoHistorico[]>([]);
  const [tendencia, setTendencia]     = useState<TendenciaDTO | null>(null);
  const [periodoLocal, setPeriodoLocal] = useState<PeriodoFiltro>({
    inicio: filtros.inicio,
    fim:    filtros.fim,
  });
  const [loading, setLoading]         = useState(false);
  const [agrupamento, setAgrupamento] = useState<Agrupamento>('dia');
  const [tooltip, setTooltip]         = useState<TooltipState>({
    visible: false, x: 0, y: 0, data: '', total: 0, agrupamento: 'dia',
  });

  const containerRef    = useRef<HTMLDivElement>(null);
  const wrapperRef      = useRef<HTMLDivElement>(null);
  const chartRef        = useRef<IChartApi | null>(null);
  const mainSeriesRef   = useRef<ISeriesApi<'Line'> | null>(null);
  const mmSeriesRef     = useRef<ISeriesApi<'Line'> | null>(null);

  useEffect(() => {
    setPeriodoLocal({ inicio: filtros.inicio, fim: filtros.fim });
  }, [globalVersao]); // eslint-disable-line react-hooks/exhaustive-deps

  const buscar = useCallback(async (f: FiltrosRelatorio, agrup: Agrupamento) => {
    setLoading(true);
    try {
      const resposta = await relatorios.historico({
        inicio:      f.inicio ? toISOLocal(f.inicio)        : undefined,
        fim:         f.fim    ? toISOLocal(f.fim, true)     : undefined,
        agrupamento: agrup,
      });
      // O backend retorna { pontos, tendencia }
      // Se ainda retorna array (versão antiga), mantém compatibilidade
      if (Array.isArray(resposta)) {
        setDados(resposta);
        setTendencia(null);
      } else {
        const r = resposta as { pontos: PontoHistorico[]; tendencia: TendenciaDTO | null };
        setDados(r.pontos);
        setTendencia(r.tendencia);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    buscar({ ...filtros, ...periodoLocal }, agrupamento);
  }, [periodoLocal, agrupamento, globalVersao]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!containerRef.current || dados.length === 0) return;

    if (chartRef.current) {
      chartRef.current.remove();
      chartRef.current = null;
      mainSeriesRef.current = null;
      mmSeriesRef.current = null;
    }

    const chart = createChart(containerRef.current, {
      width: containerRef.current.clientWidth,
      height: 260,
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#6b7280',
        fontSize: 11,
        fontFamily: 'inherit',
      },
      grid: {
        vertLines: { color: 'rgba(255,255,255,0.04)' },
        horzLines: { color: 'rgba(255,255,255,0.04)' },
      },
      crosshair: {
        mode: CrosshairMode.Magnet,
        vertLine: {
          color: 'rgba(124,58,237,0.5)',
          width: 1,
          style: LineStyle.Solid,
          labelBackgroundColor: '#7c3aed',
        },
        horzLine: {
          color: 'rgba(124,58,237,0.3)',
          width: 1,
          style: LineStyle.Dashed,
          labelBackgroundColor: '#7c3aed',
          labelVisible: false,
        },
      },
      rightPriceScale: {
        borderVisible: false,
        scaleMargins: { top: 0.1, bottom: 0.05 },
      },
      timeScale: {
        borderVisible: false,
        fixLeftEdge: true,
        fixRightEdge: true,
        tickMarkFormatter: (time: Time) => formatarLabel(time as string, agrupamento),
      },
      handleScroll: { mouseWheel: false, pressedMouseMove: true, horzTouchDrag: true },
      handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: false },
    });

    const mainSeries = chart.addSeries(LineSeries, {
      color: '#7c3aed',
      lineWidth: 2,
      crosshairMarkerVisible: true,
      crosshairMarkerRadius: 4,
      crosshairMarkerBackgroundColor: '#7c3aed',
      lastValueVisible: false,
      priceLineVisible: false,
    });

    const mmSeries = chart.addSeries(LineSeries, {
      color: '#a78bfa',
      lineWidth: 2,
      lineStyle: LineStyle.Dashed,
      crosshairMarkerVisible: false,
      lastValueVisible: false,
      priceLineVisible: false,
    });

    mainSeries.setData(dados.map(d => ({ time: toTime(d.data), value: d.total })));
    mmSeries.setData(
      dados.filter(d => d.mm !== undefined).map(d => ({ time: toTime(d.data), value: d.mm as number }))
    );
    chart.timeScale().fitContent();

    chart.subscribeCrosshairMove((param: MouseEventParams) => {
      if (!param.point || !param.time || !wrapperRef.current) {
        setTooltip(t => ({ ...t, visible: false }));
        return;
      }
      const mainVal = param.seriesData.get(mainSeries);
      const mmVal   = param.seriesData.get(mmSeries);
      if (!mainVal) { setTooltip(t => ({ ...t, visible: false })); return; }
      const timeStr = param.time as string;
      const ponto   = dados.find(d => toTime(d.data) === timeStr);
      setTooltip({
        visible: true,
        x: param.point.x,
        y: param.point.y,
        data: ponto?.data ?? timeStr,
        total: (mainVal as LineData).value,
        mm: mmVal ? (mmVal as LineData).value : undefined,
        agrupamento,
      });
    });

    const ro = new ResizeObserver(entries => { chart.resize(entries[0].contentRect.width, 260); });
    ro.observe(containerRef.current);
    chartRef.current      = chart;
    mainSeriesRef.current = mainSeries;
    mmSeriesRef.current   = mmSeries;

    return () => { ro.disconnect(); chart.remove(); chartRef.current = null; };
  }, [dados, agrupamento]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="card p-5 space-y-4">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="relative group/label inline-block">
            <h2 className="section-title cursor-default">Fluxo de Reservas</h2>
            <div className="absolute top-full left-0 mt-1 hidden group-hover/label:block z-50 pointer-events-none">
              <div className="bg-black border border-gray-700 rounded-lg shadow-xl px-3 py-1.5 text-xs whitespace-nowrap text-gray-300">
                Total de reservas finalizadas ao longo do tempo
              </div>
            </div>
          </div>

          {tendencia && (
            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
              tendencia.subindo
                ? 'text-emerald-400 bg-emerald-400/10'
                : 'text-rose-400 bg-rose-400/10'
            }`}>
              {tendencia.subindo ? '↑' : '↓'} {tendencia.pct.toFixed(1)}%
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <FiltroPeriodoInline
            valor={periodoLocal}
            onChange={p => setPeriodoLocal(p)}
            comBotaoAplicar
          />
          <div className="w-px h-4 bg-white/10" />
          <div className="flex items-center gap-1 bg-[var(--surface-2)] rounded-lg p-1">
            {(['dia', 'semana', 'mes'] as Agrupamento[]).map(a => (
              <button
                key={a}
                onClick={() => setAgrupamento(a)}
                className={`text-xs px-3 py-1.5 rounded-md font-medium transition-all ${
                  agrupamento === a
                    ? 'bg-violet-600 text-white shadow-sm'
                    : 'text-[var(--text-muted)] hover:text-[var(--text-primary)]'
                }`}
              >
                {a === 'dia' ? 'Dia' : a === 'semana' ? 'Semana' : 'Mês'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="h-64 rounded-lg shimmer" />
      ) : dados.length === 0 ? (
        <div className="h-64 flex items-center justify-center text-sm text-[var(--text-muted)]">
          Nenhum dado no período selecionado
        </div>
      ) : (
        <div className="w-full relative" ref={wrapperRef}>
          <div ref={containerRef} className="w-full" />
          <Tooltip state={tooltip} />
        </div>
      )}

      {!loading && dados.length > 0 && (
        <div className="flex items-center gap-4 px-2 text-xs text-[var(--text-muted)]">
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-0.5 bg-violet-600 rounded" />
            <span>Reservas</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-0" style={{ borderTop: '1.5px dashed #a78bfa' }} />
            <span>Média {JANELA_MM[agrupamento]}p</span>
          </div>
        </div>
      )}
    </div>
  );
}
